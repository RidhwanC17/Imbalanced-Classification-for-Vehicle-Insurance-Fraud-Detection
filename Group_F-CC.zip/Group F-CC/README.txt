Group F-CC - Imbalanced Classification for Vehicle Insurance Fraud Detection
============================================================================

Contents
  Report_Group_F-CC.pdf        Project report
  code/New_Insurance_C.py      Full analysis script (EDA, models, evaluation, figures)
  code/requirements.txt        Python packages used
  outputs/eda_outputs/         EDA tables, figures and eda_findings.txt
  outputs/model_outputs/       CV and test results, figures, model_selection_report.txt

Dataset
  Public Kaggle dataset "Vehicle Insurance Claim Fraud Detection":
  https://www.kaggle.com/datasets/shivamb/vehicle-claim-fraud-detection
  Download fraud_oracle.csv and rename it to vehicle_insurance.csv.

How to run
  1. pip install -r code/requirements.txt
  2. Put vehicle_insurance.csv in the same folder as New_Insurance_C.py
     (or pass --data-path path/to/file.csv)
  3. python New_Insurance_C.py

  The full run takes about 12 minutes on a 2-core machine. All random steps use
  seed 2026, so the results in the report are reproduced exactly. Outputs are
  written to eda_outputs/ and model_outputs/ next to the script.

  Versions used for the report: Python 3.13, pandas 3.0.5, NumPy 2.5.3,
  SciPy 1.18.1, scikit-learn 1.9.1, imbalanced-learn 0.14.2, Matplotlib 3.11.2.
